<?php

// namespace Wor\Fields\Post;

// use Wor\Fields\Helpers\Importer;
// use StoutLogic\AcfBuilder\FieldsBuilder;

// $importer = new Importer();

// $settings = new FieldsBuilder('page_settings', [
//   'title' => 'Settings'
// ]);

// $settings
//   ->setLocation('post_type', '==', 'page');
  
// $settings
//   ->addFields($importer->get_partial('partials.general'))
//     ->removeField('enable_featured_image');

// return $settings;

return null;
