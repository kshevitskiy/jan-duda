<?php

// namespace Wor\Fields\Post;

// use Wor\Fields\Helpers\Importer;
// use StoutLogic\AcfBuilder\FieldsBuilder;

// $importer = new Importer();

// $settings = new FieldsBuilder('post_settings', [
//   'title' => 'Settings'
// ]);

// $settings
//   ->setLocation('post_type', '==', 'post');
  
// $settings
//   ->addFields($importer->get_partial('partials.general'));

// return $settings;

return null;
