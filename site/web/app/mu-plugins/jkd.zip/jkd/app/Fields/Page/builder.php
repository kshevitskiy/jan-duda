<?php

// namespace Wor\Fields\Page;

// use Wor\Fields\Helpers\Importer;
// use StoutLogic\AcfBuilder\FieldsBuilder;

// $importer = new Importer();
// $builder = new FieldsBuilder('builder');
// $builderTemplate = 'views/template-builder.blade.php';

// $builder
//   ->setLocation('page_template', '==', $builderTemplate);
// $builder
//   ->addFields($importer->get_partial('partials.builder'));    

// return $builder;

?>